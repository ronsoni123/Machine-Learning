import pandas as pd
import numpy as np
from matplotlib import pyplot as plt
df=pd.read_csv("train.csv")

plt.subplot2grid((2,3),(0,0))
df.Survived.value_counts(normalize=True).plot(kind="bar",alpha=0.5)
plt.title("Survived")

plt.subplot2grid((2,3),(0,1))
plt.scatter(df.Survived,df.Age,alpha=0.1)
plt.title("Age wrt Survived")


plt.subplot2grid((2,3),(0,2))
df.Pclass.value_counts(normalize=True).plot(kind="bar",alpha=0.5)
plt.title("Class")

plt.subplot2grid((2,3),(1,0),colspan=2)
for x in [1,2,3]:
    df.Age[df.Pclass==x].plot(kind="kde")#kde=kernel density estimation
plt.title("class wrt age")
plt.legend(("1st",'2nd','3rd'))


plt.subplot2grid((2,3),(1,2))
df.Embarked.value_counts(normalize=True).plot(kind="bar",alpha=0.5)
plt.title("passengers embarked")
plt.show()



def clean_data(data):
    data["Fare"] = data["Fare"].fillna(data["Fare"].dropna().median())
    data["Age"] = data["Age"].fillna(data["Age"].dropna().median())
    
    data.loc[data["Sex"]=="male","Sex"]=0
    data.loc[data["Sex"]=="female","Sex"]=1
    
    data["Embarked"]=data["Embarked"].fillna("S")
    data.loc[data["Embarked"]=="S","Embarked"]=0
    data.loc[data["Embarked"]=="C","Embarked"]=1
    data.loc[data["Embarked"]=="Q","Embarked"]=2


from sklearn.model_selection import train_test_split