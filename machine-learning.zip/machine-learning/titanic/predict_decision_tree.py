import pandas as pd
import numpy as np
import utils
from  sklearn import tree,model_selection

def clean_data(data):
    data["Fare"] = data["Fare"].fillna(data["Fare"].dropna().median())
    data["Age"] = data["Age"].fillna(data["Age"].dropna().median())
    
    data.loc[data["Sex"]=="male","Sex"]=0
    data.loc[data["Sex"]=="female","Sex"]=1
    
    data["Embarked"]=data["Embarked"].fillna("S")
    data.loc[data["Embarked"]=="S","Embarked"]=0
    data.loc[data["Embarked"]=="C","Embarked"]=1
    data.loc[data["Embarked"]=="Q","Embarked"]=2  

train = pd.read_csv("train.csv")
clean_data(train)

target=train["Survived"].values
feature_names=["Pclass","Age","Fare","Embarked","Sex","SibSp","Parch"]
features = train[feature_names].values



decision_tree = tree.DecisionTreeClassifier(random_state = 1)
decision_tree_ = decision_tree.fit(features,target)

print(decision_tree.score(features,target))

scores=model_selection.cross_val_score(decision_tree,features,target,scoring="accuracy",cv=50)
print(scores)
print(scores.mean())

generalized_tree = tree.DecisionTreeClassifier(random_state = 1,max_depth=7,min_samples_split=2)
generalized_tree_ = generalized_tree.fit(features,target)

scores=model_selection.cross_val_score(generalized_tree,features,target,scoring="accuracy",cv=50)
print(scores)
print(scores.mean())

tree.export_graphviz(generalized_tree_,feature_names=feature_names,out_file="tree.png")