import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
df=pd.read_csv("train.csv")

female_color="#FA0000"
#fig,(ax1,ax2,ax3)=plt.subplots(1,3)
figure=plt.figure(figsize=(18,12))

plt.subplot2grid((3,4),(0,0))
df.Survived.value_counts(normalize=True).plot(kind="bar",alpha=0.5)
plt.title("Survived")

plt.subplot2grid((3,4),(0,1))
df.Survived[df.Sex=="male"].value_counts(normalize=True).plot(kind="bar",alpha=0.5)
plt.title("male survived")

plt.subplot2grid((3,4),(0,2))
df.Survived[df.Sex=="female"].value_counts(normalize=True).plot(kind="bar",alpha=0.5,color=female_color)
plt.title("female survived")

plt.subplot2grid((3,4),(0,3))
df.Sex[df.Survived==1].value_counts(normalize=True).plot(kind="bar",alpha=0.5,color=[female_color,'b'])
plt.title("sex of survived")

plt.subplot2grid((3,4),(1,0),colspan=4)
for x in [1,2,3]:
    df.Survived[df.Pclass==x].plot(kind="kde")#kde=kernel density estimation
plt.title("class wrt survived  ")
plt.legend(("1st",'2nd','3rd'))

plt.subplot2grid((3,4),(2,0))
df.Survived[(df.Sex=="male")&(df.Pclass==1)].value_counts(normalize=True).plot(kind="bar",alpha=0.5)
plt.title("Rich men Survived")

plt.subplot2grid((3,4),(2,1))
df.Survived[(df.Sex=="male")&(df.Pclass==3)].value_counts(normalize=True).plot(kind="bar",alpha=0.5)
plt.title("Poor men Survived")

plt.subplot2grid((3,4),(2,2))
df.Survived[(df.Sex=="female")&(df.Pclass==1)].value_counts(normalize=True).plot(kind="bar",alpha=0.5,color=female_color)
plt.title("Rich women Survived")

plt.subplot2grid((3,4),(2,3))
df.Survived[(df.Sex=="female")&(df.Pclass==3)].value_counts(normalize=True).plot(kind="bar",alpha=0.5,color=female_color)
plt.title("Poor women Survived")

plt.show()